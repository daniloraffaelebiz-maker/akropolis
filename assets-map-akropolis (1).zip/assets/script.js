// Akropolis scripts
console.log("Akropolis loaded");
